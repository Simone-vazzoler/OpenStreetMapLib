/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package OpenStreetMap;

import org.w3c.dom.NodeList;

/**
 *
 * @author vazzoler_simone
 */
public class Place {
    float lat, lon;
    
    String street, town, country, state, country_code, post_code;
    
    public Place() {
        
    }

    public String getCountry_code() {
        return country_code;
    }

    public void setCountry_code(String country_code) {
        this.country_code = country_code;
    }

    public String getPost_code() {
        return post_code;
    }

    public void setPost_code(String post_code) {
        this.post_code = post_code;
    }

    
    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    
    public String getTown() {
        return town;
    }

    public void setTown(String town) {
        this.town = town;
    }
   

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }
    
    
    public Place(float lat, float lon) {
        this.lat = lat;
        this.lon = lon;
    }

    public float getLat() {
        return lat;
    }

    public void setLat(float lat) {
        this.lat = lat;
    }

    public float getLon() {
        return lon;
    }

    public void setLon(float lon) {
        this.lon = lon;
    }

    public String toString(){
        return "Citta: " + town + "Paese: "+ country + "Regione: " + state + "Via: " + street + "Codice postale: " + post_code + "Codice paese: " + country_code + "Latitudine: " + lat + "Longitudine: " + lon;
        
    }
    

}
