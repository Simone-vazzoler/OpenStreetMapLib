/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package OpenStreetMap;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import static java.util.stream.DoubleStream.builder;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 *
 * @author vazzoler_simone
 */
public class OpenMap {

    //ritorna lista di place
    public static List<Place> getPlaces(String citta) throws UnsupportedEncodingException, MalformedURLException, ParserConfigurationException, SAXException, IOException {

        List<Place> listaPlace = new ArrayList<Place>();
        String value = URLEncoder.encode(citta, StandardCharsets.UTF_8.toString());
        URL url = new URL("https://nominatim.openstreetmap.org/search?q=" + value + "&format=xml&addressdetails=1");
        Element root= getRoot(url);
        
       
        NodeList lista = root.getElementsByTagName("place");
        for(int i = 0; i < lista.getLength(); i++){
            float lat=0, lon = 0;
            String town = "", country = "", street = "";
            
            
            Element place = (Element)lista.item(i);
            Place tmp= new Place();
            
            lat = Float.parseFloat(place.getAttribute("lat"));
            lon = Float.parseFloat(place.getAttribute("lon"));
            
            //lista temporanea in cui metto tutti i tag street
            street = getTag(place,"street");
            town = getTag(place,"town");
            country = getTag(place,"country");
  
            tmp.setCountry(country);
            tmp.setStreet(street);
            tmp.setTown(town);
            tmp.setLat(lat);
            tmp.setLon(lon);
            
            listaPlace.add(tmp);
            
        }
        return listaPlace;
    }

    //metodo che mi ritorna un intero root di un url
    private static Element getRoot(URL url) throws ParserConfigurationException, SAXException, IOException {

        Document document;
        DocumentBuilderFactory factory;
        DocumentBuilder builder;
        Element root, element;
        NodeList nodelist;
        
        factory = DocumentBuilderFactory.newInstance();
        builder = factory.newDocumentBuilder();

        document = builder.parse(url.openStream());
        root = document.getDocumentElement();
        return root;
    }
    
    
    private static String getTag(Element place, String tag){
        String contentTag ="";
        NodeList tmpnl;
        
        tmpnl = place.getElementsByTagName(tag);
        
        if(tmpnl.getLength()>0){
            contentTag = place.getElementsByTagName(tag).item(0).getTextContent();
            return contentTag;
            
        }else{
            return "";
        }
  
    }

}
